"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Pencil, Trash2 } from "lucide-react"

interface Stock {
  id: number
  quantity: number
  product: { id: number; name: string; costPrice: number }
  capital: { id: number; name: string }
}

interface Product {
  id: number
  name: string
  costPrice: number
}

interface Capital {
  id: number
  name: string
  remaining: number
  status: string
  permanentlyClosed: boolean
}

export default function StockPage() {
  const [stocks, setStocks] = useState<Stock[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [capitals, setCapitals] = useState<Capital[]>([])

  const [selectedProduct, setSelectedProduct] = useState("")
  const [selectedCapital, setSelectedCapital] = useState("")
  const [quantity, setQuantity] = useState("")

  const [editing, setEditing] = useState<Stock | null>(null)

  useEffect(() => {
    fetch("/api/stock").then((res) => res.json()).then(setStocks)
    fetch("/api/products").then((res) => res.json()).then(setProducts)
    fetch("/api/capital")
      .then((res) => res.json())
      .then((data) => {
        const openCapitals = data.filter(
          (c: Capital) => c.status === "open" && !c.permanentlyClosed
        )
        setCapitals(openCapitals)
      })
  }, [])

  const getCost = () => {
    const product = products.find((p) => p.id === Number(selectedProduct))
    return product ? product.costPrice * Number(quantity || 0) : 0
  }

  const handleAdd = async () => {
    const res = await fetch("/api/stock", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        productId: Number(selectedProduct),
        capitalId: Number(selectedCapital),
        quantity: parseInt(quantity),
      }),
    })

    if (!res.ok) {
      const msg = await res.text()
      alert(msg === "Insufficient capital" ? "❌ Not enough capital remaining!" : msg)
      return
    }

    const newStock = await res.json()
    setStocks([newStock, ...stocks])
    setQuantity("")
    setSelectedCapital("")
    setSelectedProduct("")
  }

  const handleDelete = async (id: number) => {
    await fetch(`/api/stock/${id}`, { method: "DELETE" })
    setStocks((prev) => prev.filter((s) => s.id !== id))
  }

  return (
    <div className="pt-12 md:pt-0">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Stock</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button>Add Stock</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Stock</DialogTitle>
            </DialogHeader>
            <div className="space-y-2">
              <Select onValueChange={setSelectedProduct} value={selectedProduct}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select Product" />
                </SelectTrigger>
                <SelectContent className="bg-white dark:bg-zinc-900 z-50 border border-gray-200 dark:border-zinc-700">
                  {products.map((product) => (
                    <SelectItem key={product.id} value={String(product.id)}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select onValueChange={setSelectedCapital} value={selectedCapital}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select Capital" />
                </SelectTrigger>
                <SelectContent className="bg-white dark:bg-zinc-900 z-50 border border-gray-200 dark:border-zinc-700">
                  {capitals.map((cap) => (
                    <SelectItem key={cap.id} value={String(cap.id)}>
                      {cap.name} – MVR {cap.remaining.toLocaleString()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Input
                type="number"
                placeholder="Quantity"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />

              <p className="text-sm text-muted-foreground">
                Cost: MVR {getCost().toLocaleString()}
              </p>

              <Button onClick={handleAdd}>Add</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="overflow-auto rounded border border-gray-200 bg-white dark:bg-gray-800">
        <table className="w-full text-sm text-left">
          <thead className="bg-green-700 text-white">
            <tr>
              <th className="px-4 py-2">Product</th>
              <th className="px-4 py-2">Capital</th>
              <th className="px-4 py-2">Quantity</th>
              <th className="px-4 py-2 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {stocks.map((stock) => (
              <tr key={stock.id} className="border-b dark:border-gray-700">
                <td className="px-4 py-2">{stock.product.name}</td>
                <td className="px-4 py-2">{stock.capital.name}</td>
                <td className="px-4 py-2">{stock.quantity}</td>
                <td className="px-4 py-2 text-center space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setEditing(stock)}
                  >
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete this stock entry?</AlertDialogTitle>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(stock.id)}>
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
