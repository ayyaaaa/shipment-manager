"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"

import Link from "next/link"

interface Report {
    stocks: {
        id: number
        quantity: number
        createdAt: string
        product: {
            name: string
            costPrice: number
        }
    }[]
    expenses: {
        id: number
        type: string
        amount: number
        createdAt: string
    }[]
}

export default function CapitalUsagePage() {
    const { id } = useParams()
    const [report, setReport] = useState<Report | null>(null)

    useEffect(() => {
        const fetchReport = async () => {
            try {
                const res = await fetch(`/api/capital/${id}/report`)
                if (!res.ok) throw new Error("Failed to load capital report")
                const json = await res.json()
                setReport(json)
            } catch (err) {
                console.error("Error loading report:", err)
            }
        }

        fetchReport()
    }, [id])

    if (!report) return <div className="p-4">Loading...</div>

    return (
        <div className="p-4 space-y-8">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold">Capital Usage Report</h1>
                <Button asChild className="bg-green-700">
                    <a
                        href={`/api/capital/${id}/report?pdf=true`}
                        download={`capital-${id}-report.pdf`}
                    >
                        Download PDF
                    </a>    
                </Button>


            </div>

            {/* Stock Table */}
            <div className="overflow-auto rounded border border-gray-200 bg-white dark:bg-gray-800">
                <h2 className="text-xl font-semibold px-4 pt-4 pb-2">Stocks Purchased</h2>
                <table className="w-full text-sm text-left">
                    <thead className="bg-green-700 text-white">
                        <tr>
                            <th className="px-4 py-2">Product</th>
                            <th className="px-4 py-2">Quantity</th>
                            <th className="px-4 py-2">Used On</th>
                            <th className="px-4 py-2">Value Used (MVR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {report.stocks.map((s) => (
                            <tr key={s.id} className="border-b dark:border-gray-700">
                                <td className="px-4 py-2">{s.product.name}</td>
                                <td className="px-4 py-2">{s.quantity}</td>
                                <td className="px-4 py-2">
                                    {new Date(s.createdAt).toLocaleString()}
                                </td>
                                <td className="px-4 py-2">
                                    MVR {(s.quantity * s.product.costPrice).toFixed(2)}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Expenses Table */}
            <div className="overflow-auto rounded border border-gray-200 bg-white dark:bg-gray-800">
                <h2 className="text-xl font-semibold px-4 pt-4 pb-2">Expenses</h2>
                <table className="w-full text-sm text-left">
                    <thead className="bg-green-700 text-white">
                        <tr>
                            <th className="px-4 py-2">Type</th>
                            <th className="px-4 py-2">Amount (MVR)</th>
                            <th className="px-4 py-2">Used On</th>
                        </tr>
                    </thead>
                    <tbody>
                        {report.expenses.map((e) => (
                            <tr key={e.id} className="border-b dark:border-gray-700">
                                <td className="px-4 py-2">{e.type}</td>
                                <td className="px-4 py-2">MVR {e.amount.toFixed(2)}</td>
                                <td className="px-4 py-2">
                                    {new Date(e.createdAt).toLocaleString()}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    )
}
