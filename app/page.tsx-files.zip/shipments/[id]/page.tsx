// ✅ FILE: app/shipments/[id]/page.tsx

"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"

interface ShipmentDetail {
  id: number
  name: string
  status: string
  shipmentDate: string
  createdAt: string
  capital: { name: string }
  items: { quantity: number, product: { name: string }, customer: { outlet: string } }[]
  expenses: { amount: number, expenseType: { name: string } }[]
}

export default function ShipmentDetailPage() {
  const { id } = useParams()
  const [shipment, setShipment] = useState<ShipmentDetail | null>(null)

  useEffect(() => {
    fetch(`/api/shipments/${id}`).then(res => res.json()).then(setShipment)
  }, [id])

  if (!shipment) return <div className="p-4">Loading...</div>

  const totalExpense = shipment.expenses.reduce((sum, e) => sum + e.amount, 0)

  return (
    <div className="p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Shipment: {shipment.name}</h1>
        <Button onClick={() => window.open(`/api/shipments/${shipment.id}/report?pdf=true`, '_blank')}>Download PDF</Button>
      </div>

      <div className="text-sm space-y-1">
        <p><strong>Status:</strong> {shipment.status}</p>
        <p><strong>Date:</strong> {new Date(shipment.shipmentDate).toLocaleDateString()}</p>
        <p><strong>Created:</strong> {new Date(shipment.createdAt).toLocaleString()}</p>
        <p><strong>Capital Used:</strong> {shipment.capital.name}</p>
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-2">Items by Customer</h2>
        <div className="overflow-auto">
          <table className="w-full text-sm border">
            <thead className="bg-green-700 text-white">
              <tr>
                <th className="px-3 py-2">Customer</th>
                <th className="px-3 py-2">Product</th>
                <th className="px-3 py-2">Quantity</th>
              </tr>
            </thead>
            <tbody>
              {shipment.items.map((item, idx) => (
                <tr key={idx} className="border-b">
                  <td className="px-3 py-2">{item.customer.outlet}</td>
                  <td className="px-3 py-2">{item.product.name}</td>
                  <td className="px-3 py-2">{item.quantity}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-2">Expenses</h2>
        <div className="overflow-auto">
          <table className="w-full text-sm border">
            <thead className="bg-green-700 text-white">
              <tr>
                <th className="px-3 py-2">Expense Type</th>
                <th className="px-3 py-2">Amount (MVR)</th>
              </tr>
            </thead>
            <tbody>
              {shipment.expenses.map((exp, idx) => (
                <tr key={idx} className="border-b">
                  <td className="px-3 py-2">{exp.expenseType.name}</td>
                  <td className="px-3 py-2">MVR {exp.amount.toFixed(2)}</td>
                </tr>
              ))}
              <tr className="font-semibold">
                <td className="px-3 py-2 text-right">Total:</td>
                <td className="px-3 py-2">MVR {totalExpense.toFixed(2)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}